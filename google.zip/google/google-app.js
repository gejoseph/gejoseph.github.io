Splitting(); 

ScrollOut({  
  threshold: .1,
  once: true
});